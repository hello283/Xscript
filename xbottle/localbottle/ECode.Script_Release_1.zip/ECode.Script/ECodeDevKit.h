#include "ElangInclude.h"

union fbyte{
    char b[4];
    int i;
};

enum vtype{
    eint = 0,
    ebool = 1,
    echar = 2,
    estr = 3,
    nul = 4
};

enum scopeType{
    function = 0,
    _if = 1,
    _else = 2
};

enum funtype{
    local=0,
    oslib=1,
    share=2
};

class var{
    private:
        vtype type = nul;
        string mem;
    public:
        bool exist = false;
        var(int i){
            mem = "";
            fbyte fb;
            fb.i = i;
            for(int i = 0;i < 4;i++){
                mem += fb.b[i];
            }
            type = eint;
            exist = true;
        }

        var(bool b){
            mem = "";
            mem = (b) ? 1 : 0;
            type = ebool;
            exist = true;
        }

        var(char c){
            mem = "";
            mem += c;
            type = ebool;
            exist = true;
        }

        var(){}

        var(string str){
            mem = "";
            mem = str;
            type = estr;
            exist = true;
        }

        string Content(){
            return mem;
        }

        vtype Type(){
            return type;
        }

        
        void add(var *a){
            if(type != a->Type())  return;
            switch (a->Type())
            {
            case nul:
                perror("Logic Error: You trying to add a void type string!");
                exit(-1);
                break;
            
            case eint:
                fbyte fb;
                for(int i = 0;i < 4;i++){
                    fb.b[i] = a->Content()[i];
                }
                fbyte fb1;
                for(int i = 0;i < 4;i++){
                    fb1.b[i] = mem[i];
                }

                fb1.i += fb.i;
                for(int i = 0;i < 4;i++){
                    mem[i] = fb1.b[i];
                }
                break;

            case echar:
                mem[0] += a->Content()[0];
                break;

            case ebool:
                mem[0] += a->Content()[0];
                break;

            case estr:
                mem += a->Content()[0];
                break;

            default:
                break;
            }
        }

        void sub(var *a){
            if(type != a->Type())  return;
            switch (a->Type())
            {
            case nul:
                perror("Logic Error: You trying to sub a void type string!");
                exit(-1);
                break;
            
            case eint:
                fbyte fb;
                for(int i = 0;i < 4;i++){
                    fb.b[i] = a->Content()[i];
                }

                fbyte fb1;
                for(int i = 0;i < 4;i++){
                    fb1.b[i] = mem[i];
                }

                fb1.i -= fb.i;
                for(int i = 0;i < 4;i++){
                    mem[i] = fb1.b[i];
                }
                break;

            case echar:
                mem[0] -= a->Content()[0];
                break;

            case ebool:
                mem[0] -= a->Content()[0];
                break;

            case estr:
                perror("Syntax Error: Bad String Operator!\n");
                break;

            default:
                break;
            }
        }

        void sub(char chr){
            // 也是属于字符串类更改
            if(type != echar)  return;
            mem[0] -= chr;
        }

        void by(int arg){
            if(type != eint)  {perror("Syntax Error: Var Type Not int!\n");exit (-1);}
            fbyte fb1;
            for(int i = 0;i < 4;i++){
                fb1.b[i] = mem[i];
            }
            fb1.i*=arg;
            for(int i = 0;i < 4;i++){
                mem[i] = fb1.b[i];
            }    
        }

        void remainder(int arg){
            if(type != eint)  {perror("Syntax Error: Var Type Not int!\n");exit (-1);}
            fbyte fb1;
            for(int i = 0;i < 4;i++){
                fb1.b[i] = mem[i];
            }
            fb1.i = fb1.i % arg;
            for(int i = 0;i < 4;i++){
                mem[i] = fb1.b[i];
            }    
        }

        void division(int arg){
            if(type != eint)  {perror("Syntax Error: Var Type Not int!\n");exit (-1);}
            fbyte fb1;
            for(int i = 0;i < 4;i++){
                fb1.b[i] = mem[i];
            }
            fb1.i = fb1.i / arg;
            for(int i = 0;i < 4;i++){
                mem[i] = fb1.b[i];
            }    
        }
};

class functionObj{
    public:
    string fname;
    vector<vtype> argType;
    vtype returnType = nul;
    vector<string> fbody;
    funtype ftype;
    string sharepath = "";
    bool exist = false;
};

namespace api{
    vector<string> CodeSplit(string toSplit,char spliter){
        vector<string> result;
        bool flag = false;
        int taowa = 0;
        string tmp;
        for(int i = 0;i < toSplit.length();i++){
            if(toSplit[i] == '"'){
                //cout << "There is a \"!Flag Coverted!\n";
                flag = !flag;
                //continue;
            }
            if(toSplit[i] == spliter){
                if(flag || (!flag && taowa != 0)){
                    //cout<< "Here Is Flag!Continue!\n";
                    goto con;
                }
                else{
                    //cout << flag << endl;
                    //cout << toSplit[i] << ": There Not Flags!Pushing to array!\n";
                    result.push_back(tmp);
                    tmp = "";
                    continue;
                }
            }
            if(toSplit[i] == '{' && !flag){
                taowa++;
            }
            if(toSplit[i] == '}' && !flag){
                taowa--;
            }
            
            con:
            tmp += toSplit[i];
            if(i == toSplit.length() - 1){
                //cout << "There Is End Of Str!\n";
                result.push_back(tmp);
                tmp = "";
                continue;
            }
            /**/
        }
        return result;
    }
    string CodeFormatter(string toSplit,char spliter){
        vector<string> result;
        int taowa = 0;
        bool flag = false,isEmpty = false,bkh = false,ftw = false,blankInStart;
        //stack<int> taowa;
        string tmp;
        for(int i = 0;i < toSplit.length();i++){
            // 语句前空格解析
            if(toSplit[i] == '\n' && toSplit[i + 1] == ' '){
                blankInStart = true;
                continue;
            }
            if(blankInStart == true && toSplit[i] != ' '){
                blankInStart = false;
            }
            if(blankInStart == true && toSplit[i] == ' '){
                continue;
            }
            // 注释解析
            if(toSplit[i] == '/' && toSplit[i + 1] == '/'){
                isEmpty = true;
            }
            if(isEmpty == true){
                if(toSplit[i] == '\n')  {isEmpty = false;}
                continue;
            }

            // 代码块优化
            /*
            function{
                name: Main;
                arg: string;
                returnT : int;
            }fbody{
                return 0;
            };
            转换成
            function{    name: Main;    arg: string;    returnT: int}fbody{    return 0;}
            */
            if(toSplit[i] == '{' && !flag){
                // Left brackets processing
                // 由于会重复设置bkh的量，所以交给递归来实现
                if(bkh == true){
                    /* 不造咋写，先搁置着 */
                    taowa++;
                    //continue;
                }else{
                    bkh = true;
                    ftw = true;
                }
            }

            if(bkh && !flag){
                if(toSplit[i] == '}'){
                    //cout << "你觉得我可能会被执行吗?" << taowa << "\n"; 
                    
                    if(taowa) {taowa--;goto rtw;}
                    if(toSplit[i + 1] == ';'){
                        // 真正的结束，如果定义后面不是换行符，继续不处理换行符
                        tmp += toSplit[i];
                        bkh = false;
                        result.push_back(tmp);
                        tmp = "";
                        continue;
                        // 保存代码进数组
                    }else{ /* Do Nothings */}
                }
                if(toSplit[i] == '\n') continue;
                if(toSplit[i] == spliter) goto con;
            }
            rtw:
            if(toSplit[i] == spliter){
                if(flag){
                    //cout<< "Here Is Flag!Continue!\n";
                    //continue;
                }
                else{
                    //cout << toSplit[17] << ": There Not Flags!Pushing to array!\n";
                    result.push_back(tmp);
                    tmp = "";
                    continue;
                }
            }    
            if(toSplit[i + 1] == '"'){
                //cout << "There is a \"!Flag Coverted!\n";
                flag = !flag;
            }
            con:
            endofloop:
            tmp += toSplit[i];
            if(i == toSplit.length() - 1){
                //cout << "There Is End Of Str!\n";
                result.push_back(tmp);
                tmp = "";
                continue;
            }
            /**/
        }
        return result[0];
    }

    vector<string> blockScripter(string toSplit){
        string formated = CodeFormatter(toSplit,'\n');
        vector<string> result;
        bool flag = false;
        int taowa = 0;
        string tmp;
        for(int i = 0;i < formated.length();i++){
            if(formated[i] == '{'){
                taowa++;
            }
            if(formated[i] == '}'){
                taowa--;
            }
            if(i > 0 && formated[i - 1] == '}' && formated[i] == ';' && taowa==0){
                // 大括号解析
                result.push_back(tmp);
                tmp = "";
                continue;
            }
            if(formated[i] == '\n'){
                if(flag){
                    //cout<< "Here Is Flag!Continue!\n";
                    //continue;
                }
                else{
                    //cout << toSplit[17] << ": There Not Flags!Pushing to array!\n";
                    result.push_back(tmp);
                    tmp = "";
                    continue;
                }
            }
            if(formated[i + 1] == '"'){
                //cout << "There is a \"!Flag Coverted!\n";
                flag = !flag;
            }
            tmp += formated[i];
            if(i == formated.length() - 1){
                //cout << "There Is End Of Str!\n";
                result.push_back(tmp);
                tmp = "";
                continue;
            }
        }
        return result;
    }
    
    size_t find(string str,char ch,int start = 0){
        int taowa = 0,taowa1 = 0;
        bool bkh = 0,xkh = 0,instr = 0;
        for(int i = start;i < str.length();i++){
            if(str[i] == '"')  instr = !instr;
            if(str[i] == '(' && !instr){
                taowa++;
                if(xkh == true)  {goto con;}
                xkh = true;
            }
            if(str[i] == ')' && !instr){
                taowa--;
            }
            if(str[i] == '{' && !instr){
                taowa1++;
                if(bkh == true)  {goto con;}
                bkh = true;
            }
            if(str[i] == '}' && !instr){
                taowa1--;
            }
            con:
            //cout << taowa << " " << taowa1 << endl;
            if(str[i] == ch && taowa == 0 && taowa1 == 0 && !instr){
                return i;
            }
        }
        return 18446744073709551615;
    }

    vtype toVtype(string str){
        if(str == "int")  return eint;
        if(str == "void") return nul;
        if(str == "char") return echar;
        if(str == "string") return estr;
        return nul;
    }
}

string&   replace_all(string&   str,const   string&   old_value,const   string&   new_value)     
{     
    while(true){     
        string::size_type pos(0);     
        if((pos=str.find(old_value))!=string::npos)     
            str.replace(pos,old_value.length(),new_value);     
        else break;     
    }     
    return str;     
}     

var redirectStr(var ostr){
    string toReplace = ostr.Content();
    size_t s = 0;
    // 按优先级进行替换

    replace_all(toReplace,"\\\\","__qwkdjqwodkjqwodjqowdjiqowdjoqwdj__"); 
    replace_all(toReplace,"\\a","\a");
    replace_all(toReplace,"\\b","\b");
    replace_all(toReplace,"\\f","\f");
    replace_all(toReplace,"\\t","\t");
    replace_all(toReplace,"\\v","\v");
    replace_all(toReplace,"\\n","\n");
    replace_all(toReplace,"\\r","\r");
    replace_all(toReplace,"\\0","\0");
    replace_all(toReplace,"__qwkdjqwodkjqwodjqowdjiqowdjoqwdj__","\\");
    return toReplace;
}