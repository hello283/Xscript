#include "ECodeDevKit.h"
using namespace std;

extern "C" var max(vector<var> args){
    //cout << "In Library Function: max\n";
    var a = var(0);
    if(args.size() > 2)  return a;
    if(args[0].Type() != args[1].Type())  return a;
    if(args[0].Content() > args[1].Content()) return args[0];
    return args[1];
}

extern "C" var min(vector<var> args){
    //cout << "In Library Function: min\n";
    var a = var(0);
    //if(args.size() > 2)  return a;
    if(args[0].Type() != args[1].Type())  return a;
    if(args[0].Content() < args[1].Content()) return args[0];
    return args[1];
}

extern "C" var substr(vector<var> args){
    //cout << "In Library Function: substr\n";
    var a = var(-25565);
    if(args.size() < 2)  return a;
    if(args[0].Type() != estr)  return a;
    if(args[1].Type() != eint)  return a;
    if(args[2].Type() != eint)  return a;
    fbyte fb0;
    for(int i = 0;i < 4;i++){
        fb0.b[i] = args[1].Content()[i];
    }
    fbyte fb1;
    for(int i = 0;i < 4;i++){
        fb1.b[i] = args[2].Content()[i];
    }
    var ret = args[0].Content().substr(fb0.i,fb1.i);
    return ret;
}
/*print(n);*/
extern "C" var print(vector<var> args){
    //cout << "In Library Function: print\n";
    for(int i = 0;i < args.size();i++){
        if(args[i].Type() == eint){
            fbyte fb;
            for(int j = 0;j < 4;j++){
                fb.b[j] = args[i].Content()[j];
            }
            cout << fb.i;
        }else if(args[i].Type() == estr){
            cout << args[i].Content();
        }else if(args[i].Type() == echar){
            cout << args[i].Content();
        }else if(args[i].Type() == ebool){
            cout << (int)args[i].Content()[0];
        }else{
            cout << "ECode Standard Library Error: Unknown Var Type!\n";
            exit(-1);
        }
    }
    var result = var(0);
    return result;
}

extern "C" var input(vector<var> args){
    //cout << "In Library Function: Input\n";
    string str;
    getline(cin,str);
    var result_int = var(atoi(str.data()));
    var result_str = var(str);
    var result_chr = var(str[0]);
    var result_bol = var((bool)str[0]);
    if(args[0].Type() == eint){
        return result_int;
    }else if(args[0].Type() == echar){
        return result_chr;
    }else if(args[0].Type() == ebool){
        return result_bol;
    }else if(args[0].Type() == estr){
        return result_str;
    }
    return result_str;
}

extern "C" var _sleep(vector<var> args){
    var a=var(-25565);
    if(args[0].Type() != eint)  return a;
    fbyte sec;
    for(int i = 0;i < 4;i++){
        sec.b[i] = args[0].Content()[i];
    }
    sleep(sec.i);
    return var(1);
}

extern "C" var _usleep(vector<var> args){
    var a=var(-25565);
    if(args[0].Type() != eint)  return a;   
    fbyte ms;
    for(int i = 0;i < 4;i++){
        ms.b[i] = args[0].Content()[i];
    }
    sleep(ms.i);
    return var(1);
}