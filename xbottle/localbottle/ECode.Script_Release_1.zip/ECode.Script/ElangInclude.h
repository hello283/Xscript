#include <iostream>           // Basic C++ Class
#include <cstdio>             // Useful for c
#include <algorithm>          // More Algorithm Function
#include <vector>             // Useful Array
#include <cstdlib>            // More STD Function
#include <ios>                // I/O Stream
#include <unistd.h>           // More Useful Function
#include <map>                // C++ Dataobject Map
//#include <sys/types.h>        // linuxC++ Operation Library
#include <dirent.h>           // linuxC++ Operation Library
#include <queue>
//#include <sys/stat.h>         // linuxC++ Operation Library
//#include <sys/types.h>
#include <sys/socket.h>
// #include </usr/include/sys/dir.h>
#include <ftw.h>
// #include <io.h>               // File Input & Output
#include <stdio.h>
#include <fcntl.h>
#include <cstring>

using namespace std;          // Include Std namespace

// User Define
#include "ElangageFramework.h"
// Main Function For Test

