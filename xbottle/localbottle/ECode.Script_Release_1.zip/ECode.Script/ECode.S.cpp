// Ecode.Script
// Owner: player0010
// Powered by ECode Developer Team.
// Site: www.00010.ml
#include "ElangInclude.h"
#include "dlfcn.h"
using namespace std;

string runinpath;

union fbyte{
    char b[4];
    int i;
};

enum vtype{
    eint = 0,
    ebool = 1,
    echar = 2,
    estr = 3,
    nul = 4
};

enum scopeType{
    function = 0,
    _if = 1,
    _else = 2
};

enum funtype{
    local=0,
    oslib=1,
    share=2
};

string colegg[] = {
    "PHP是世界上最好deyuyan（被吃瓜群众拍死",
    "鸡你太美!",
    "在？适配一下IE?",
    "针不戳，住在山里针不戳",
    "Talk is cheap. Show me the code",
    "金坷垃好处都有啥？",
    "Android上能提高学习、工作效率的应用有哪些？ ——关机.",
    "看！你写的程序有Bug!",
    "sudo rm -rf /* 是一个快捷的磁盘清理工具!\n",
    "反编译你麻痹，我艹你全家,************************************,希望你全家有事🙏"
};

class var{
    private:
        vtype type = nul;
        string mem;
    public:
        bool exist = false;
        var(int i){
            mem = "";
            fbyte fb;
            fb.i = i;
            for(int i = 0;i < 4;i++){
                mem += fb.b[i];
            }
            type = eint;
            exist = true;
        }

        var(bool b){
            mem = "";
            mem = (b) ? 1 : 0;
            type = ebool;
            exist = true;
        }

        var(char c){
            mem = "";
            mem += c;
            type = ebool;
            exist = true;
        }

        var(){}

        var(string str){
            mem = "";
            mem = str;
            type = estr;
            exist = true;
        }

        string Content(){
            return mem;
        }

        vtype Type(){
            return type;
        }

        
        void add(var *a){
            if(type != a->Type())  return;
            switch (a->Type())
            {
            case nul:
                perror("Logic Error: You trying to add a void type string!");
                exit(-1);
                break;
            
            case eint:
                fbyte fb;
                for(int i = 0;i < 4;i++){
                    fb.b[i] = a->Content()[i];
                }
                fbyte fb1;
                for(int i = 0;i < 4;i++){
                    fb1.b[i] = mem[i];
                }

                fb1.i += fb.i;
                for(int i = 0;i < 4;i++){
                    mem[i] = fb1.b[i];
                }
                break;

            case echar:
                mem[0] += a->Content()[0];
                break;

            case ebool:
                mem[0] += a->Content()[0];
                break;

            case estr:
                mem += a->Content()[0];
                break;

            default:
                break;
            }
        }

        void sub(var *a){
            if(type != a->Type())  return;
            switch (a->Type())
            {
            case nul:
                perror("Logic Error: You trying to sub a void type string!");
                exit(-1);
                break;
            
            case eint:
                fbyte fb;
                for(int i = 0;i < 4;i++){
                    fb.b[i] = a->Content()[i];
                }

                fbyte fb1;
                for(int i = 0;i < 4;i++){
                    fb1.b[i] = mem[i];
                }

                fb1.i -= fb.i;
                for(int i = 0;i < 4;i++){
                    mem[i] = fb1.b[i];
                }
                break;

            case echar:
                mem[0] -= a->Content()[0];
                break;

            case ebool:
                mem[0] -= a->Content()[0];
                break;

            case estr:
                perror("Syntax Error: Bad String Operator!\n");
                break;

            default:
                break;
            }
        }

        void sub(char chr){
            // 也是属于字符串类更改
            if(type != echar)  return;
            mem[0] -= chr;
        }

        void by(int arg){
            if(type != eint)  {perror("Syntax Error: Var Type Not int!\n");exit (-1);}
            fbyte fb1;
            for(int i = 0;i < 4;i++){
                fb1.b[i] = mem[i];
            }
            fb1.i*=arg;
            for(int i = 0;i < 4;i++){
                mem[i] = fb1.b[i];
            }    
        }

        void remainder(int arg){
            if(type != eint)  {perror("Syntax Error: Var Type Not int!\n");exit (-1);}
            fbyte fb1;
            for(int i = 0;i < 4;i++){
                fb1.b[i] = mem[i];
            }
            fb1.i = fb1.i % arg;
            for(int i = 0;i < 4;i++){
                mem[i] = fb1.b[i];
            }    
        }

        void division(int arg){
            if(type != eint)  {perror("Syntax Error: Var Type Not int!\n");exit (-1);}
            fbyte fb1;
            for(int i = 0;i < 4;i++){
                fb1.b[i] = mem[i];
            }
            fb1.i = fb1.i / arg;
            for(int i = 0;i < 4;i++){
                mem[i] = fb1.b[i];
            }    
        }
};

class functionObj{
    public:
    string fname;
    vector<vtype> argType;
    vtype returnType = nul;
    vector<string> fbody;
    funtype ftype;
    string sharepath = "";
    bool exist = false;
};

class sscope{
    public:
    map<string,sscope> nscope;
    map<string,functionObj> flist;
    map<string,var> vlist;
};

sscope global;
string inScope;

namespace api{
    string gcwd(string rp){
        vector<string> rt = Text::split(rp,"/");
        string result;
        for(int i = 0;i < rt.size() - 1;i++){
            result += '/';
            result += rt[i];
        }
        result.erase(result.begin() + 1);
        return result;
    }
    vector<string> CodeSplit(string toSplit,char spliter){
        vector<string> result;
        bool flag = false;
        int taowa = 0;
        string tmp;
        for(int i = 0;i < toSplit.length();i++){
            if(toSplit[i] == '"'){
                //cout << "There is a \"!Flag Coverted!\n";
                flag = !flag;
                //continue;
            }
            if(toSplit[i] == spliter){
                if(flag || (!flag && taowa != 0)){
                    //cout<< "Here Is Flag!Continue!\n";
                    goto con;
                }
                else{
                    //cout << flag << endl;
                    //cout << toSplit[i] << ": There Not Flags!Pushing to array!\n";
                    result.push_back(tmp);
                    tmp = "";
                    continue;
                }
            }
            if(toSplit[i] == '{' && !flag){
                taowa++;
            }
            if(toSplit[i] == '}' && !flag){
                taowa--;
            }
            
            con:
            tmp += toSplit[i];
            if(i == toSplit.length() - 1){
                //cout << "There Is End Of Str!\n";
                result.push_back(tmp);
                tmp = "";
                continue;
            }
            /**/
        }
        return result;
    }
    string CodeFormatter(string toSplit,char spliter){
        vector<string> result;
        int taowa = 0;
        bool flag = false,isEmpty = false,bkh = false,ftw = false,blankInStart;
        //stack<int> taowa;
        string tmp;
        for(int i = 0;i < toSplit.length();i++){
            // 语句前空格解析
            if(toSplit[i] == '\n' && toSplit[i + 1] == ' '){
                blankInStart = true;
                continue;
            }
            if(blankInStart == true && toSplit[i] != ' '){
                blankInStart = false;
            }
            if(blankInStart == true && toSplit[i] == ' '){
                continue;
            }
            // 注释解析
            if(toSplit[i] == '/' && toSplit[i + 1] == '/'){
                isEmpty = true;
            }
            if(isEmpty == true){
                if(toSplit[i] == '\n')  {isEmpty = false;}
                continue;
            }
            // 去除多余换行
            if(toSplit[i] == '\n'){
                continue;
            }
            // 代码块优化
            /*
            function{
                name: Main;
                arg: string;
                returnT : int;
            }fbody{
                return 0;
            };
            转换成
            function{    name: Main;    arg: string;    returnT: int}fbody{    return 0;}
            */
            if(toSplit[i] == '{' && !flag){
                // Left brackets processing
                // 由于会重复设置bkh的量，所以交给递归来实现
                if(bkh == true){
                    /* 不造咋写，先搁置着 */
                    taowa++;
                    //continue;
                }else{
                    bkh = true;
                    ftw = true;
                }
            }

            if(bkh && !flag){
                if(toSplit[i] == '}'){
                    //cout << "你觉得我可能会被执行吗?" << taowa << "\n"; 
                    
                    if(taowa) {taowa--;goto rtw;}
                    if(toSplit[i + 1] == ';'){
                        // 真正的结束，如果定义后面不是换行符，继续不处理换行符
                        tmp += toSplit[i];
                        bkh = false;
                        result.push_back(tmp);
                        tmp = "";
                        continue;
                        // 保存代码进数组
                    }else{ /* Do Nothings */}
                }
                if(toSplit[i] == '\n') continue;
                if(toSplit[i] == spliter) goto con;
            }
            rtw:   
            if(toSplit[i + 1] == '"'){
                //cout << "There is a \"!Flag Coverted!\n";
                flag = !flag;
            }
            con:
            endofloop:
            tmp += toSplit[i];
            if(i == toSplit.length() - 1){
                //cout << "There Is End Of Str!\n";
                result.push_back(tmp);
                tmp = "";
                continue;
            }
            /**/
        }
        return result[0];
    }

    vector<string> blockScripter(string toSplit){
        string formated = CodeFormatter(toSplit,'\n');
        vector<string> result;
        bool flag = false;
        int taowa = 0;
        string tmp;
        for(int i = 0;i < formated.length();i++){
            if(formated[i] == '{'){
                taowa++;
            }
            if(formated[i] == '}'){
                taowa--;
            }
            if(i > 0 && formated[i - 1] == '}' && formated[i] == ';' && taowa==0){
                // 大括号解析
                result.push_back(tmp);
                tmp = "";
                continue;
            }
            if(i > 0 && formated[i-1] == ')' && formated[i] == ';' && taowa == 0){
                result.push_back(tmp);
                tmp = "";
                continue;
            }
            if(formated[i] == '\n'){
                if(flag){
                    //cout<< "Here Is Flag!Continue!\n";
                    //continue;
                }
                else{
                    //cout << toSplit[17] << ": There Not Flags!Pushing to array!\n";
                    result.push_back(tmp);
                    tmp = "";
                    continue;
                }
            }
            if(formated[i + 1] == '"'){
                //cout << "There is a \"!Flag Coverted!\n";
                flag = !flag;
            }
            tmp += formated[i];
            if(i == formated.length() - 1){
                //cout << "There Is End Of Str!\n";
                result.push_back(tmp);
                tmp = "";
                continue;
            }
        }
        return result;
    }
    
    size_t find(string str,char ch,int start = 0){
        int taowa = 0,taowa1 = 0;
        bool bkh = 0,xkh = 0,instr = 0;
        for(int i = start;i < str.length();i++){
            if(str[i] == '"')  instr = !instr;
            if(str[i] == '(' && !instr){
                taowa++;
                if(xkh == true)  {goto con;}
                xkh = true;
            }
            if(str[i] == ')' && !instr){
                taowa--;
            }
            if(str[i] == '{' && !instr){
                taowa1++;
                if(bkh == true)  {goto con;}
                bkh = true;
            }
            if(str[i] == '}' && !instr){
                taowa1--;
            }
            con:
            //cout << taowa << " " << taowa1 << endl;
            if(str[i] == ch && taowa == 0 && taowa1 == 0 && !instr){
                return i;
            }
        }
        return 18446744073709551615;
    }

    vtype toVtype(string str){
        if(str == "int")  return eint;
        if(str == "void") return nul;
        if(str == "char") return echar;
        if(str == "string") return estr;
        return nul;
    }
}

string&   replace_all(string&   str,const   string&   old_value,const   string&   new_value)     
{     
    while(true){     
        string::size_type pos(0);     
        if((pos=str.find(old_value))!=string::npos)     
            str.replace(pos,old_value.length(),new_value);     
        else break;     
    }     
    return str;     
}     

var redirectStr(var ostr){
    string toReplace = ostr.Content();
    size_t s = 0;
    // 按优先级进行替换

    replace_all(toReplace,"\\\\","__qwkdjqwodkjqwodjqowdjiqowdjoqwdj__"); 
    replace_all(toReplace,"\\a","\a");
    replace_all(toReplace,"\\b","\b");
    replace_all(toReplace,"\\f","\f");
    replace_all(toReplace,"\\t","\t");
    replace_all(toReplace,"\\v","\v");
    replace_all(toReplace,"\\n","\n");
    replace_all(toReplace,"\\r","\r");
    replace_all(toReplace,"\\0","\0");
    replace_all(toReplace,"__qwkdjqwodkjqwodjqowdjiqowdjoqwdj__","\\");
    replace_all(toReplace,"__COMPILER_SHARELIB_PATH__",runinpath + "/include");
    return toReplace;
}

functionObj parseToFunObj(string func){
    // 分解函数块
    functionObj fobj;
    string tmpStr[2];
    vector<string> arg;
    int point = 0;
    size_t lpos = func.find('{');
    size_t rpos = func.find('}');
    tmpStr[0] = Text::getSubText(func,lpos + 1,rpos-lpos-1);
    lpos = func.find('{',lpos+1);
    rpos = func.length() - 1;
    tmpStr[1] = Text::getSubText(func,lpos + 1,rpos-lpos-1);
    arg = api::CodeSplit(tmpStr[0],';');
    
    // 对函数头部进行解析
    int complete;
    for(int i = 0;i < arg.size();i++){
        vector<string> info = Text::split(arg[i],":");
        if(info[0] == "name"){
            fobj.fname = info[1];
            complete++;
        }else if(info[0] == "argT"){
            vtype vart;
            if(info[1] == "int"){
                vart = eint;
            }else if(info[1] == "bool"){
                vart = ebool;
            }else if(info[1] == "char"){
                vart = echar;
            }else if(info[1] == "void"){
                vart = nul;
            }else if(info[1] == "string"){
                vart = estr;
            }else{
                cout << "In here: " << info[1];
                perror("Syntax Error: Unknown var type!");
                exit(-1);
            }
            fobj.argType.push_back(vart);
        }else if(info[0] == "returnT"){
            vtype vart;
            if(info[1] == "int"){
                vart = eint;
            }else if(info[1] == "bool"){
                vart = ebool;
            }else if(info[1] == "char"){
                vart = echar;
            }else if(info[1] == "void"){
                vart = nul;
            }else if(info[1] == "string"){
                vart = estr;
            }else{
                cout << "In here: " << info[1];
                perror("Syntax Error: Unknown var type!\n");
                exit(-1);
            }
            fobj.returnType = vart;
        }else if(info[0] == "sharelib"){
            //cout << "Kao!";
            if(info[1] == "")  {perror("Syntax Error: ShareLib path must be a string!");exit(-1);}
            fobj.ftype=share;
            fobj.sharepath=info[1];
            vector<string> codeBlocks = api::CodeSplit(tmpStr[1],';');
            fobj.fbody = codeBlocks;
            fobj.exist = true;
            return fobj;
        }else{
            cout << "In here: " << func;
            perror("Syntax Error: Invalid function header!\n");
            exit(-1);
        }
    }
    // 代码块加入
    //cout << tmpStr[1] << endl;
    fobj.ftype=local;
    vector<string> codeBlocks = api::CodeSplit(tmpStr[1],';');
    fobj.fbody = codeBlocks;
    fobj.exist = true;
    
    return fobj;
}

bool functionexist(string fcall);
var callFunction(functionObj fobj,string callf,bool lockscope);

var parseToVarobj(string staticvar){
    size_t lft = staticvar.find('(');
    string fname = staticvar.substr(0,lft);
    if(functionexist(fname)){
        var a = callFunction(global.flist[fname],staticvar,false);
        return a;
    }
    //cout << staticvar.substr(0,7);
    if(global.vlist[staticvar].exist == true){        
        //cout << "From Exist Var\n";
        return global.vlist[staticvar];
    }
    if(staticvar.length() >= 8 && staticvar.substr(0,8) == "colorEgg"){
        srand(time(0));
        var result = var(colegg[rand() % 8]);
        return result;
    }
    else if(staticvar == "void"){
        var result;
        return result;
    }else if(staticvar[0] == '"'){
        var result = var(redirectStr(staticvar.substr(1,staticvar.length() - 1 - 1)));
        //cout << result.Content() << endl;
        return result;
    }
    bool isint = true;
    for(int i = 0;i < staticvar.length();i++){
        //cout << (int)staticvar[i];
        if(staticvar[i] < 48 || staticvar[i] > 57){
            //cout << "Falsed\n";
            isint = false;
            break;
        }
    }
    if(isint){
        var result = var(atoi(staticvar.data()));
        return result;
    }else if(staticvar[0] == '\''){
        if(staticvar[2] != '\''){
            perror("Syntax Error: Need a '\n");
            exit(-1);
        }
        var result = var(staticvar[1]);
        return result;
    }else{
        size_t action[] = {
            api::find(staticvar,'+'),
            api::find(staticvar,'-'),
            api::find(staticvar,'*'),
            api::find(staticvar,'/'),
            api::find(staticvar,'%')
        };
        if(action[0] != 18446744073709551615){
            // 执行加法运算
            vector<string> sped = api::CodeSplit(staticvar,'+');
            var a = parseToVarobj(sped[0]);
            var b = parseToVarobj(sped[1]);
            a.add(&b);
            return a;
        }
        else if(action[1] != 18446744073709551615){
            // 执行减法运算
            vector<string> sped = api::CodeSplit(staticvar,'-');
            var a = parseToVarobj(sped[0]);
            var b = parseToVarobj(sped[1]);
            a.sub(&b);
            return a;
        }
        else if(action[2] != 18446744073709551615){
            vector<string> sped = api::CodeSplit(staticvar,'*');
            var a = parseToVarobj(sped[0]);
            var b = parseToVarobj(sped[1]);
            if(b.Type() != eint){perror("SyntaxError: Wrong Var Type!\n");exit(-1);}
            fbyte fb;
            for(int i = 0;i < 4;i++){
                fb.b[i] = b.Content()[i];
            }
            a.by(fb.i);
            return a;
        }
        else if(action[3] != 18446744073709551615){
            vector<string> sped = api::CodeSplit(staticvar,'/');
            var a = parseToVarobj(sped[0]);
            var b = parseToVarobj(sped[1]);
            if(b.Type() != eint){perror("SyntaxError: Wrong Var Type!\n");exit(-1);}
            fbyte fb;
            for(int i = 0;i < 4;i++){
                fb.b[i] = b.Content()[i];
            }
            a.division(fb.i);
            return a;
        }
        else if(action[4] != 18446744073709551615){
            vector<string> sped = api::CodeSplit(staticvar,'%');
            var a = parseToVarobj(sped[0]);
            var b = parseToVarobj(sped[1]);
            if(b.Type() != eint){perror("SyntaxError: Wrong Var Type!\n");exit(-1);}
            fbyte fb;
            for(int i = 0;i < 4;i++){
                fb.b[i] = b.Content()[i];
            }
            a.remainder(fb.i);
            return a;
        }
    }
    cout << "In here: " << staticvar;
    perror("Syntax Error: Unknown Var Source!\n");
    exit(-1);
}
/* >= <= == != > < */
bool logicProcess(string exp){
    size_t s[] = {
        exp.find("=="),
        exp.find(">="),
        exp.find("<="),
        exp.find("!="),
        exp.find(">"),
        exp.find("<"),
    };
    //cout << s[3];
    //size_t s = exp.find("==");
    if(s[0] != 18446744073709551615){
        var a = parseToVarobj(exp.substr(0,s[0]));
        var b = parseToVarobj(exp.substr(s[0] + 2,exp.length() - 2));
        if(a.Type() != b.Type()){
            goto error;
        }else{
            if(a.Content() == b.Content()){
                return true;
            }else{
                return false;
            }
        }
    }else if(s[1] != 18446744073709551615){
        var a = parseToVarobj(exp.substr(0,s[1]));
        var b = parseToVarobj(exp.substr(s[1] + 2,exp.length() - 2));
        if(a.Type() != b.Type()){
            goto error;
        }else{
            if(a.Content() >= b.Content()){
                return true;
            }else{
                return false;
            }
        }
    }else if(s[2] != 18446744073709551615){
        var a = parseToVarobj(exp.substr(0,s[2]));
        var b = parseToVarobj(exp.substr(s[2] + 2,exp.length() - 2));
        if(a.Type() != b.Type()){
            goto error;
        }else{
            if(a.Content() <= b.Content()){
                return true;
            }else{
                return false;
               }
        }
    }else if(s[3] != 18446744073709551615){
        var a = parseToVarobj(exp.substr(0,s[3]));
        //cout << exp.substr(s[3]+2,exp.length() - 2) << endl;
        var b = parseToVarobj(exp.substr(s[3] + 2,exp.length() - 2));
        if(a.Type() != b.Type()){
            goto error;
        }else{
            if(a.Content() != b.Content()){
                return true;
            }else{
                return false;
            }
        }
    }else if(s[4] != 18446744073709551615){
        var a = parseToVarobj(exp.substr(0,s[4]));
        var b = parseToVarobj(exp.substr(s[4] + 1,exp.length() - 1));
        if(a.Type() != b.Type()){
            goto error;
        }else{
            if(a.Content() > b.Content()){
                return true;
            }else{
                return false;
            }
        }
    }else if(s[5] != 18446744073709551615){
        var a = parseToVarobj(exp.substr(0,s[5]));
        var b = parseToVarobj(exp.substr(s[5] + 1,exp.length() - 1));
        if(a.Type() != b.Type()){
            goto error;
        }else{
            if(a.Content() < b.Content()){
                return true;
            }else{
                return false;
            }
        }
   }else{
        perror("Syntax Error: Invalid Logic Expression\n");
        exit(-1);
    }

    error:
    perror("Syntax Error: Type Error!\n");
    exit(-1);
}

bool functionexist(string fcall){
    size_t lft = fcall.find('(');
    string fname = fcall.substr(0,lft);
    return global.flist[fname].exist;
}

var callFunction(functionObj fobj,string callf,bool lockscope = false){
    var fresult;
    //fresult.returnType = fobj.returnType;
    // 参数处理
    //cout << fobj.fname << endl;
    size_t fndres = callf.find("(");
    if(callf[callf.length() - 1] != ')'){
        cout << callf;
        perror("Syntax Error: Missing ')'\n");
        exit(-1);
    }
    if(!lockscope)  inScope = fobj.fname;
    vector<string> callarg = api::CodeSplit(callf.substr(fndres,callf.length() - fndres - 1),',');
    callarg[0].erase(callarg[0].begin());
    // 判断是否为系统库函数
    if(fobj.ftype == share){
        var fshare = parseToVarobj(fobj.sharepath);
        //cout << fshare.Content() << " " << fobj.fname.data() << endl;
        void* fhandle = dlopen(fshare.Content().data(),RTLD_LAZY);
        if(fhandle == NULL)  exit(-1);
        //cout << fhandle;
        var (*callfun)(vector<var>);
        vector<var> tocall;
        for(int i = 0;i < callarg.size();i++){
            tocall.push_back(parseToVarobj(callarg[i]));
        }
        //(var (*)(std::vector<var>)) 
        string cppctsy = fobj.fname;
        callfun = (var (*)(vector<var>))dlsym(fhandle,fobj.fname.data());
        //cout << "callfun:" << *callfun << endl;
        //cout << *callfun << endl;
        var ret = callfun(tocall);
        dlclose(fhandle);
        return ret;
    }else{
        // 若否，执行代码块
        for(int i = 0;i < fobj.fbody.size();i++){
            //cout << fobj.fbody[i] << "\n";
            if(fobj.fbody[i] == ""){
                continue;
            }
            else if(fobj.fbody[i].length() > 2 && Text::getLeftText(fobj.fbody[i],3) == "if("){
                size_t right = api::find(fobj.fbody[i],')',0);
                string exp = fobj.fbody[i].substr(3,right - 3);
                size_t lft = right+1;
                size_t rgt = api::find(fobj.fbody[i],'}',0);
                if(fobj.fbody[i][lft] != '{'){
                    perror("Syntax Error: Need a '{'\n");
                    exit(-1);
                }
                if(logicProcess(exp)){
                    //cout << fobj.fbody[i][lft] << "  " << fobj.fbody[i][rgt];
                    string block = fobj.fbody[i].substr(lft+1,rgt - lft - 1);
                    vector<string> fbdy = api::CodeSplit(block,';');
                    functionObj f;
                    f.fbody = fbdy;
                    f.exist = true;
                    f.returnType = nul;
                    f.argType.push_back(nul);
                    //cout << f.fbody[0];
                    callFunction(f,"f(void)",true);
                }else{
                    rgt++;
                    lft = rgt;
                    if(fobj.fbody[i].substr(lft,4) == "else"){
                        lft+=4;
                        rgt = api::find(fobj.fbody[i],'}',(int)lft);
                        string block = fobj.fbody[i].substr(lft+1,rgt-lft-1);
                        vector<string> fbdy = api::CodeSplit(block,';');
                        functionObj f;
                        f.fbody = fbdy;
                        f.exist = true;
                        f.returnType = nul;
                        f.argType.push_back(nul);
                        callFunction(f,"f(void)",true);
                    }
                }
            }
            else if(fobj.fbody[i].length() > 6 && Text::getLeftText(fobj.fbody[i],6) == "while("){
                size_t right = api::find(fobj.fbody[i],')',0);
                string exp = fobj.fbody[i].substr(6,right - 6);
                size_t lft = right+1;
                size_t rgt = api::find(fobj.fbody[i],'}',0);
                if(fobj.fbody[i][lft] != '{'){
                    perror("Syntax Error: Need a '{'\n");
                    exit(-1);
                }
                while(logicProcess(exp)){
                    //cout << fobj.fbody[i][lft] << "  " << fobj.fbody[i][rgt];
                    string block = fobj.fbody[i].substr(lft+1,rgt - lft - 1);
                    vector<string> fbdy = api::CodeSplit(block,';');
                    functionObj f;
                    f.fbody = fbdy;
                    f.exist = true;
                    f.returnType = nul;
                    f.argType.push_back(nul);
                    //cout << f.fbody[0];
                    callFunction(f,"f(void)",true);
                }
            }
            // getVarArg
            else if(fobj.fbody[i].length() > 9 && Text::getLeftText(fobj.fbody[i],9) == "getFunArg"){
                size_t right = api::find(fobj.fbody[i],')',0);
                string exp = fobj.fbody[i].substr(9+1,right - 9 - 1);
                vector<string> args = api::CodeSplit(exp,',');
                //cout << args[1] << endl;
                var cs = parseToVarobj(args[1]);
                if(cs.Type() != eint)  {perror("Logic Error: Arg Index's Type Must Be Int!\n");exit(-1);}
                fbyte fb;
                for(int i = 0;i < 4;i++){
                    fb.b[i] = cs.Content()[i];
                }
                vtype argtype = fobj.argType[fb.i];
                //cout << callarg[fb.i] << fobj.fname;
                var a = parseToVarobj(callarg[fb.i]);
                if(a.Type() != argtype){perror("Logic Error: Wrong ArgType!\n");exit(-1);}
                global.vlist[args[0]] = a;
            }
            else if(fobj.fbody[i].length() > 4 && Text::getLeftText(fobj.fbody[i],4) == "var "){
                vector<string> yj = api::CodeSplit(fobj.fbody[i].substr(4,fobj.fbody[i].length() - 2),'=');
                var vobj = parseToVarobj(yj[1]);
                global.vlist[yj[0]] = vobj;
                //cout << global.vlist[yj[0]].Content() << endl << yj[0] << endl;
            }
            if(fobj.fbody[i].length() > 7 && Text::getLeftText(fobj.fbody[i],7) == "return "){
                var funback = parseToVarobj(fobj.fbody[i].substr(7));
                return funback;
            }
            //cout << fobj.fbody[i] << "WTF?" << endl;
            else if(functionexist(fobj.fbody[i])){
                size_t lft = fobj.fbody[i].find('(');
                string fname = fobj.fbody[i].substr(0,lft);
                callFunction(global.flist[fname],fobj.fbody[i]);
            }
        }
    }
    return fresult;
}

int pre_processing_core(string file){
    vector<string> fdata = api::blockScripter(api::CodeFormatter(file,'\n'));
    for(int i = 0;i < fdata.size();i++){
        if(fdata[i] == "" || fdata[i] == ";"){
            // 判断是否为无意义语句
            continue;
        }
        else if(fdata[i].length() > 8 && Text::getLeftText(fdata[i],8) == "function"){
            functionObj fobj = parseToFunObj(fdata[i]);
            global.flist[fobj.fname] = fobj;
        }
        else if(fdata[i].length() > 6 && Text::getLeftText(fdata[i],6) == "import"){
            //cout<<"Import!\n";
            size_t lft = fdata[i].find("(");
            size_t rgt = fdata[i].find(")");
            if(lft == 18446744073709551615 || rgt == 18446744073709551615){perror("Wrong Import Format!\n");exit(-1);}
            string arg = fdata[i].substr(lft+1,rgt-lft-1);
            vector<string> toImport = api::CodeSplit(arg,',');
            for(int i = 0;i < toImport.size();i++){
                if(toImport[i] == ""){
                    continue;
                }
                var importfilename = parseToVarobj(toImport[i]);
                //cout << importfilename.Content() << endl;
                string importfile = EasyFiles::ReadFile(importfilename.Content());
                pre_processing_core(importfile);
            }
        }
    }
    return 0;
}

int main(int argc,char* argv[]){
    runinpath = api::gcwd(linux_os::getRealpath(argv[0]));
    //cout << runinpath;
    string filename = argv[1];
    //cout << "Newest\n";
    var fpath = parseToVarobj("\""+filename+"\"");
    //cout << fpath.Content();
    string text = EasyFiles::ReadFile(fpath.Content());
    text += '\0';
    //string text = "-1<2";
    /*string fed = api::CodeFormatter(text,'\n');
    cout << fed << endl;
    vector<string> strarr = api::blockScripter(fed);
    for(int i = 0;i < strarr.size();i++){
        cout << strarr[i] << endl;
    }*/
    //cout << text;
    pre_processing_core(text);
    callFunction(global.flist["Main"],"Main(void)");
    //bool lgc = logicProcess(text);
    //size_t fresult = api::find(text,')',0);
    //var a = redirectStr(parseToVarobj(text));
    //cout << lgc;
}